pb = PiBot('192.168.50.1');

pb.stop();